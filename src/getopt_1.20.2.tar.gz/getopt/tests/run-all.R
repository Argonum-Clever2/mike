library("testthat")

test_check("getopt")
